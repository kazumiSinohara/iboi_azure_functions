import logging
import json
import os
from azure.cosmos import CosmosClient
import azure.functions as func

# Cosmos DB connection info from environment variables
COSMOS_URI = os.environ["COSMOS_URI"]
COSMOS_KEY = os.environ["COSMOS_KEY"]
DB_NAME = "iotdb"
CONTAINER_NAME = "devicestate"

client = CosmosClient(COSMOS_URI, COSMOS_KEY)
container = client.get_database_client(DB_NAME).get_container_client(CONTAINER_NAME)

def main(event: func.EventHubEvent):
    logging.info(f">>> IOTHUB event received for device {device_id}")
    try:
        msg = json.loads(event.get_body().decode("utf-8"))
        device_id = event.metadata["ConnectionDeviceId"]
        timestamp = event.enqueued_time.isoformat()

        document = {
            "id": device_id,
            "timestamp": timestamp,
            "location": {
                "latitude": msg.get("latitude"),
                "longitude": msg.get("longitude"),
                "direction": msg.get("eastwest-ns")
            },
            "battery_level": msg.get("battery-level"),
            "rsrp": msg.get("rsrp"),
            "csq": msg.get("csq"),
            "app_version": msg.get("app_ver"),
            "idESim": msg.get("idESim")
        }

        container.upsert_item(document)
        logging.info(f"Upserted data for device {device_id}")
    except Exception as e:
        logging.error(f"Error processing event: {e}")
